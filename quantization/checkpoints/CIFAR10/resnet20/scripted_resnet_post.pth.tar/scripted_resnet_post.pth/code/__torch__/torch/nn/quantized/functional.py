def relu(input: Tensor,
    inplace: bool=False) -> Tensor:
  _0 = "Input to \'quantized.relu\' must be quantized!"
  _1 = torch.__not__(ops.prim.is_quantized(input))
  if _1:
    ops.prim.RaiseException(_0)
  else:
    pass
  if inplace:
    _2 = torch.relu_(input)
  else:
    _2 = torch.relu(input)
  return _2
