class BatchNorm2d(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = ["running_mean", "running_var", "num_batches_tracked", ]
  weight : Tensor
  bias : Tensor
  running_mean : Tensor
  running_var : Tensor
  num_batches_tracked : Tensor
  training : bool
  scale : float
  zero_point : int
  affine : Final[bool] = True
  track_running_stats : Final[bool] = True
  momentum : Final[float] = 0.10000000000000001
  eps : Final[float] = 1.0000000000000001e-05
  num_features : Final[int] = 64
  def forward(self: __torch__.torch.nn.quantized.modules.batchnorm.___torch_mangle_56.BatchNorm2d,
    input: Tensor) -> Tensor:
    _0 = ops.quantized.batch_norm2d(input, self.weight, self.bias, self.running_mean, self.running_var, 1.0000000000000001e-05, self.scale, self.zero_point)
    return _0
