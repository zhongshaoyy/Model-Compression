class QFunctional(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  scale : float
  zero_point : int
  activation_post_process : __torch__.torch.nn.modules.linear.Identity
  def forward(self: __torch__.torch.nn.quantized.modules.functional_modules.QFunctional,
    x: Tensor) -> None:
    _0 = "Functional is not intended to use the \'forward\'. Please use the underlying operation"
    _1 = uninitialized(None)
    ops.prim.RaiseException(_0)
    return _1
  def add(self: __torch__.torch.nn.quantized.modules.functional_modules.QFunctional,
    x: Tensor,
    y: Tensor) -> Tensor:
    r = ops.quantized.add(x, y, self.scale, self.zero_point)
    r0 = (self.activation_post_process).forward(r, )
    return r0
