class Linear(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  in_features : int
  out_features : int
  scale : float
  zero_point : int
  _packed_params : __torch__.torch.nn.quantized.modules.linear.LinearPackedParams
  def forward(self: __torch__.torch.nn.quantized.modules.linear.Linear,
    x: Tensor) -> Tensor:
    _0 = ops.quantized.linear(x, self._packed_params._packed_params, self.scale, self.zero_point)
    return _0
class LinearPackedParams(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  dtype : int
  _packed_params : __torch__.torch.classes.quantized.LinearPackedParamsBase
  def forward(self: __torch__.torch.nn.quantized.modules.linear.LinearPackedParams,
    x: Tensor) -> Tensor:
    return x
  def __getstate__(self: __torch__.torch.nn.quantized.modules.linear.LinearPackedParams) -> Tuple[Tensor, Optional[Tensor], bool, int]:
    qweight, bias, = (self)._weight_bias()
    _1 = (qweight, bias, self.training, self.dtype)
    return _1
  def __setstate__(self: __torch__.torch.nn.quantized.modules.linear.LinearPackedParams,
    state: Tuple[Tensor, Optional[Tensor], bool, int]) -> None:
    self.dtype = (state)[3]
    _2 = (self).set_weight_bias((state)[0], (state)[1], )
    self.training = (state)[2]
    return None
  def _weight_bias(self: __torch__.torch.nn.quantized.modules.linear.LinearPackedParams) -> Tuple[Tensor, Optional[Tensor]]:
    _3 = "Unsupported dtype on dynamic quantized linear!"
    _4 = uninitialized(Tuple[Tensor, Optional[Tensor]])
    if torch.eq(self.dtype, 12):
      _6, _7 = ops.quantized.linear_unpack(self._packed_params)
      _5 = (_6, _7)
    else:
      if torch.eq(self.dtype, 5):
        _9, _10 = ops.quantized.linear_unpack_fp16(self._packed_params)
        _8 = (_9, _10)
      else:
        ops.prim.RaiseException(_3)
        _8 = _4
      _5 = _8
    return _5
  def set_weight_bias(self: __torch__.torch.nn.quantized.modules.linear.LinearPackedParams,
    weight: Tensor,
    bias: Optional[Tensor]) -> None:
    _11 = "Unsupported dtype on dynamic quantized linear!"
    if torch.eq(self.dtype, 12):
      _12 = ops.quantized.linear_prepack(weight, bias)
      self._packed_params = _12
    else:
      if torch.eq(self.dtype, 5):
        _13 = ops.quantized.linear_prepack_fp16(weight, bias)
        self._packed_params = _13
      else:
        ops.prim.RaiseException(_11)
    return None
