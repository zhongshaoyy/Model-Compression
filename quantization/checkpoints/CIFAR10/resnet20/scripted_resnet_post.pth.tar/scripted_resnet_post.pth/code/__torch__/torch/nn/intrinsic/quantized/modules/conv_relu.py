class ConvReLU2d(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  in_channels : int
  out_channels : int
  kernel_size : Tuple[int, int]
  stride : Tuple[int, int]
  padding : Tuple[int, int]
  dilation : Tuple[int, int]
  transposed : bool
  output_padding : Tuple[int, int]
  groups : int
  padding_mode : str
  _packed_params : __torch__.torch.classes.quantized.Conv2dPackedParamsBase
  scale : float
  zero_point : int
  def forward(self: __torch__.torch.nn.intrinsic.quantized.modules.conv_relu.ConvReLU2d,
    input: Tensor) -> Tensor:
    _0 = "Input shape must be `(N, C, H, W)`!"
    _1 = torch.ne(torch.len(torch.size(input)), 4)
    if _1:
      ops.prim.RaiseException(_0)
    else:
      pass
    _2 = ops.quantized.conv2d_relu(input, self._packed_params, self.scale, self.zero_point)
    return _2
  def __getstate__(self: __torch__.torch.nn.intrinsic.quantized.modules.conv_relu.ConvReLU2d) -> Tuple[int, int, Tuple[int, int], Tuple[int, int], Tuple[int, int], Tuple[int, int], bool, Tuple[int, int], int, str, Tensor, Optional[Tensor], float, int, bool]:
    w, b, = (self)._weight_bias()
    _3 = (self.in_channels, self.out_channels, self.kernel_size, self.stride, self.padding, self.dilation, self.transposed, self.output_padding, self.groups, self.padding_mode, w, b, self.scale, self.zero_point, self.training)
    return _3
  def __setstate__(self: __torch__.torch.nn.intrinsic.quantized.modules.conv_relu.ConvReLU2d,
    state: Tuple[int, int, Tuple[int, int], Tuple[int, int], Tuple[int, int], Tuple[int, int], bool, Tuple[int, int], int, str, Tensor, Optional[Tensor], float, int, bool]) -> None:
    self.in_channels = (state)[0]
    self.out_channels = (state)[1]
    self.kernel_size = (state)[2]
    self.stride = (state)[3]
    self.padding = (state)[4]
    self.dilation = (state)[5]
    self.transposed = (state)[6]
    self.output_padding = (state)[7]
    self.groups = (state)[8]
    self.padding_mode = (state)[9]
    _4 = (self).set_weight_bias((state)[10], (state)[11], )
    self.scale = (state)[12]
    self.zero_point = (state)[13]
    self.training = (state)[14]
    return None
  def _weight_bias(self: __torch__.torch.nn.intrinsic.quantized.modules.conv_relu.ConvReLU2d) -> Tuple[Tensor, Optional[Tensor]]:
    return (self._packed_params).unpack()
  def set_weight_bias(self: __torch__.torch.nn.intrinsic.quantized.modules.conv_relu.ConvReLU2d,
    w: Tensor,
    b: Optional[Tensor]) -> None:
    _5 = self.stride
    _6 = self.padding
    _7 = self.dilation
    _8 = self.groups
    _9, _10, = _5
    _11 = [_9, _10]
    _12, _13, = _6
    _14 = [_12, _13]
    _15, _16, = _7
    _17 = ops.quantized.conv2d_prepack(w, b, _11, _14, [_15, _16], _8)
    self._packed_params = _17
    return None
