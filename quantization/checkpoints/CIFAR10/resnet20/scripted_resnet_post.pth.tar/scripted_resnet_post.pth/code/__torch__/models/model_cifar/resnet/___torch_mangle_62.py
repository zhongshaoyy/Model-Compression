class ResNet_cifar10_small(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  cfg : List[int]
  inplanes : int
  layer : List[int]
  features : __torch__.torch.nn.modules.container.___torch_mangle_60.Sequential
  quant : __torch__.torch.nn.quantized.modules.Quantize
  dequant : __torch__.torch.nn.quantized.modules.DeQuantize
  avgpool : __torch__.torch.nn.modules.pooling.AvgPool2d
  fc : __torch__.torch.nn.modules.container.___torch_mangle_61.Sequential
  def forward(self: __torch__.models.model_cifar.resnet.___torch_mangle_62.ResNet_cifar10_small,
    x: Tensor) -> Tensor:
    x0 = (self.quant).forward(x, )
    x1 = (self.features).forward(x0, )
    x2 = (self.avgpool).forward(x1, )
    x3 = torch.view(x2, [torch.size(x2, 0), -1])
    x4 = (self.fc).forward(x3, )
    return (self.dequant).forward(x4, )
