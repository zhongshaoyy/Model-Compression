class Quantize(Module):
  __parameters__ = []
  __buffers__ = ["scale", "zero_point", ]
  scale : Tensor
  zero_point : Tensor
  training : bool
  dtype : int
  def forward(self: __torch__.torch.nn.quantized.modules.Quantize,
    X: Tensor) -> Tensor:
    _0 = torch.quantize_per_tensor(X, float(self.scale), int(self.zero_point), self.dtype)
    return _0
class DeQuantize(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.nn.quantized.modules.DeQuantize,
    Xq: Tensor) -> Tensor:
    return torch.dequantize(Xq)
