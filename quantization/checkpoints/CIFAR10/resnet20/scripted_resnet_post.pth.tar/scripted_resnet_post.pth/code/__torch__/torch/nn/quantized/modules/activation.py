class ReLU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  inplace : Final[bool] = False
  def forward(self: __torch__.torch.nn.quantized.modules.activation.ReLU,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.quantized.functional.relu
    return _0(input, False, )
