class BasicBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  stride : int
  conv : __torch__.torch.nn.modules.container.___torch_mangle_30.Sequential
  relu : __torch__.torch.nn.modules.activation.ReLU
  downsample : __torch__.torch.nn.modules.container.___torch_mangle_33.Sequential
  skip_add : __torch__.torch.nn.quantized.modules.functional_modules.FloatFunctional
  def forward(self: __torch__.models.model_cifar.resnet.___torch_mangle_34.BasicBlock,
    x: Tensor) -> Tensor:
    out = (self.skip_add).add((self.downsample).forward(x, ), (self.conv).forward(x, ), )
    return (self.relu).forward(out, )
