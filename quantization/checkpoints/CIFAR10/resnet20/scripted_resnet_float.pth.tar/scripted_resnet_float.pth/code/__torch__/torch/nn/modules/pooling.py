class AvgPool2d(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  divisor_override : Final[None] = None
  count_include_pad : Final[bool] = True
  kernel_size : Final[int] = 8
  stride : Final[int] = 8
  padding : Final[int] = 0
  ceil_mode : Final[bool] = False
  def forward(self: __torch__.torch.nn.modules.pooling.AvgPool2d,
    input: Tensor) -> Tensor:
    _0 = torch.avg_pool2d(input, [8, 8], [8, 8], [0, 0], False, True, None)
    return _0
