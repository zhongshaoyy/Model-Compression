class FloatFunctional(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  activation_post_process : __torch__.torch.nn.modules.linear.Identity
  def forward(self: __torch__.torch.nn.quantized.modules.functional_modules.FloatFunctional,
    x: Tensor) -> None:
    _0 = "FloatFunctional is not intended to use the \'forward\'. Please use the underlying operation"
    _1 = uninitialized(None)
    ops.prim.RaiseException(_0)
    return _1
  def add(self: __torch__.torch.nn.quantized.modules.functional_modules.FloatFunctional,
    x: Tensor,
    y: Tensor) -> Tensor:
    r = torch.add(x, y, alpha=1)
    r0 = (self.activation_post_process).forward(r, )
    return r0
