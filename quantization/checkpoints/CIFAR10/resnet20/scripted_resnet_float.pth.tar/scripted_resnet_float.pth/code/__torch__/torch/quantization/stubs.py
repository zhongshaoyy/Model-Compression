class QuantStub(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.quantization.stubs.QuantStub,
    x: Tensor) -> Tensor:
    return x
class DeQuantStub(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.quantization.stubs.DeQuantStub,
    x: Tensor) -> Tensor:
    return x
