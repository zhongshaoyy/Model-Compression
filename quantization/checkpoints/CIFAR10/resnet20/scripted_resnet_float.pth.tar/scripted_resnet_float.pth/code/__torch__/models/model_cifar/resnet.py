class ResNet_cifar10_small(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  cfg : List[int]
  inplanes : int
  layer : List[int]
  features : __torch__.torch.nn.modules.container.___torch_mangle_47.Sequential
  quant : __torch__.torch.quantization.stubs.QuantStub
  dequant : __torch__.torch.quantization.stubs.DeQuantStub
  avgpool : __torch__.torch.nn.modules.pooling.AvgPool2d
  fc : __torch__.torch.nn.modules.container.___torch_mangle_48.Sequential
  def forward(self: __torch__.models.model_cifar.resnet.ResNet_cifar10_small,
    x: Tensor) -> Tensor:
    x0 = (self.quant).forward(x, )
    x1 = (self.features).forward(x0, )
    x2 = (self.avgpool).forward(x1, )
    x3 = torch.view(x2, [torch.size(x2, 0), -1])
    x4 = (self.fc).forward(x3, )
    return (self.dequant).forward(x4, )
class ConvBNReLU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  __annotations__["0"] = __torch__.torch.nn.intrinsic.modules.fused.ConvReLU2d
  __annotations__["1"] = __torch__.torch.nn.modules.linear.Identity
  __annotations__["2"] = __torch__.torch.nn.modules.linear.Identity
  def forward(self: __torch__.models.model_cifar.resnet.ConvBNReLU,
    input: Tensor) -> Tensor:
    _0 = getattr(self, "0")
    _1 = getattr(self, "1")
    _2 = getattr(self, "2")
    input0 = (_0).forward(input, )
    input1 = (_1).forward(input0, )
    return (_2).forward(input1, )
  def __len__(self: __torch__.models.model_cifar.resnet.ConvBNReLU) -> int:
    return 3
class BasicBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  downsample : None
  stride : int
  conv : __torch__.torch.nn.modules.container.Sequential
  relu : __torch__.torch.nn.modules.activation.ReLU
  skip_add : __torch__.torch.nn.quantized.modules.functional_modules.FloatFunctional
  def forward(self: __torch__.models.model_cifar.resnet.BasicBlock,
    x: Tensor) -> Tensor:
    out = (self.skip_add).add(x, (self.conv).forward(x, ), )
    return (self.relu).forward(out, )
